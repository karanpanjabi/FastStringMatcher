st = ""

for i in range(int(1e4)):
    st += "a"

print(st)

print(1)

print(st[:1000])